import React from 'react';

function App() {
  return (
    <div>
      <h1>AI Voice Caller</h1>
    </div>
  );
}

export default App; 